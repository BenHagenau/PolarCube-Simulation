/*  Define X, Y, s  
* Created by: Ben K. Bradley 
* University of Colorado, Boulder
*/

// Contains values from Jan 1 2013 to Dec 31 2015

#ifndef IAU2006_XYS_H
#define IAU2006_XYS_H

extern float iau2006_XYs[7665];

#endif